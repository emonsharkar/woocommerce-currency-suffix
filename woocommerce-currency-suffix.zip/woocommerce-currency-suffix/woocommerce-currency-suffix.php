<?php
/**
 * Plugin Name: WooCommerce Currency Suffix
 * Description: Remove currency symbols and add the currency in words as a suffix to all prices.
 * Version:     Global 1
 * Author:      MD EMON SHARKAR (emonsharkar.2000@gmail.com)
 * License:     GPL-2.0+
 * Text Domain: wc-currency-suffix
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class WCCS_Currency_Suffix {
    const OPTION_KEY = 'wccs_suffix_text';
    const OPTION_PRESET_KEY = 'wccs_suffix_preset';

    public function __construct() {
        // Admin UI
        add_action( 'admin_menu', [ $this, 'add_settings_page' ] );
        add_action( 'admin_init', [ $this, 'register_settings' ] );
        add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), [ $this, 'settings_link' ] );

        // Check WooCommerce dependency
        add_action( 'admin_notices', [ $this, 'dependency_notice' ] );

        // Frontend price formatting
        add_filter( 'woocommerce_currency_symbol', [ $this, 'remove_currency_symbol' ], 10, 2 );
        add_filter( 'woocommerce_price_format', [ $this, 'price_format' ] );
    }

    public function is_woocommerce_active() {
        return class_exists( 'WooCommerce' );
    }

    public function dependency_notice() {
        if ( ! current_user_can( 'activate_plugins' ) ) { return; }
        if ( ! $this->is_woocommerce_active() ) {
            echo '<div class="notice notice-error"><p><strong>WooCommerce Currency Suffix</strong> requires WooCommerce to be installed and active.</p></div>';
        }
    }

    public function remove_currency_symbol( $currency_symbol, $currency ) {
        return ''; // remove any symbol
    }

    public function get_suffix_text() {
        $preset = get_option( self::OPTION_PRESET_KEY, 'custom' );
        $custom = get_option( self::OPTION_KEY, 'টাকা' );

        $presets = $this->presets();
        if ( $preset !== 'custom' && isset( $presets[ $preset ] ) ) {
            return $presets[ $preset ]['value'];
        }
        return $custom ?: 'টাকা';
    }

    public function price_format( $format ) {
        $suffix = $this->get_suffix_text();
        // %1$s = currency symbol (unused), %2$s = price
        return '%2$s&nbsp;' . esc_html( $suffix );
    }

    public function add_settings_page() {
        add_submenu_page(
            'woocommerce',
            __('Currency Suffix','wc-currency-suffix'),
            __('Currency Suffix','wc-currency-suffix'),
            'manage_woocommerce',
            'wc-currency-suffix',
            [ $this, 'render_settings_page' ]
        );
    }

    public function register_settings() {
        register_setting( 'wccs_settings', self::OPTION_PRESET_KEY, [
            'type' => 'string',
            'sanitize_callback' => [ $this, 'sanitize_preset' ],
            'default' => 'custom',
        ]);
        register_setting( 'wccs_settings', self::OPTION_KEY, [
            'type' => 'string',
            'sanitize_callback' => [ $this, 'sanitize_text' ],
            'default' => 'টাকা',
        ]);
    }

    public function sanitize_preset( $val ) {
        $presets = $this->presets();
        return isset( $presets[ $val ] ) || $val === 'custom' ? $val : 'custom';
    }

    public function sanitize_text( $val ) {
        $val = wp_strip_all_tags( $val );      // allow unicode
        $val = trim( $val );
        return $val;
    }

    public function presets() {
        return [
            'usd_only'   => [ 'label' => 'USD only',   'value' => 'USD only' ],
            'gbp_only'   => [ 'label' => 'GBP only',   'value' => 'GBP only' ],
            'eur_only'   => [ 'label' => 'EUR only',   'value' => 'EUR only' ],
            'jpy_only'   => [ 'label' => 'JPY only',   'value' => 'JPY only' ],
            'rial_only'  => [ 'label' => 'Rial only',  'value' => 'Rial only' ],
            'bdt_only'   => [ 'label' => 'টাকা মাত্র',    'value' => 'টাকা মাত্র' ],
            'inr_only'   => [ 'label' => 'रुपया केवल',   'value' => 'रुपया केवल' ],
            'custom'     => [ 'label' => 'Custom…',    'value' => '' ],
        ];
    }

    public function render_settings_page() {
        if ( ! current_user_can( 'manage_woocommerce' ) ) { return; }
        $presets = $this->presets();
        $current_preset = get_option( self::OPTION_PRESET_KEY, 'custom' );
        $current_text = get_option( self::OPTION_KEY, 'টাকা' );
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('WooCommerce Currency Suffix', 'wc-currency-suffix'); ?></h1>
            <p><?php esc_html_e('Remove currency symbols and add the currency in words as a suffix to all prices.', 'wc-currency-suffix'); ?></p>
            <form method="post" action="options.php">
                <?php settings_fields( 'wccs_settings' ); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="wccs_suffix_preset"><?php esc_html_e('Choose a preset', 'wc-currency-suffix'); ?></label></th>
                        <td>
                            <select name="<?php echo esc_attr( self::OPTION_PRESET_KEY ); ?>" id="wccs_suffix_preset">
                                <?php foreach ( $presets as $key => $data ) : ?>
                                    <option value="<?php echo esc_attr( $key ); ?>" <?php selected( $current_preset, $key ); ?>>
                                        <?php echo esc_html( $data['label'] ); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description"><?php esc_html_e('Pick a common wording, or choose “Custom…” to enter your own text.', 'wc-currency-suffix'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="wccs_suffix_text"><?php esc_html_e('Custom suffix', 'wc-currency-suffix'); ?></label></th>
                        <td>
                            <input type="text" class="regular-text" name="<?php echo esc_attr( self::OPTION_KEY ); ?>" id="wccs_suffix_text" value="<?php echo esc_attr( $current_text ); ?>" placeholder="e.g. USD only, GBP only, টাকা মাত্র">
                            <p class="description"><?php esc_html_e('Used when preset = Custom. Examples: “USD only”, “GBP only”, “रुपया केवल”, “টাকা মাত্র”.', 'wc-currency-suffix'); ?></p>
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <script>
            (function(){
                const preset = document.getElementById('wccs_suffix_preset');
                const customRow = document.getElementById('wccs_suffix_text').closest('tr');
                function toggle(){ customRow.style.display = preset.value === 'custom' ? '' : 'none'; }
                preset.addEventListener('change', toggle);
                toggle();
            })();
        </script>
        <?php
    }

    public function settings_link( $links ) {
        $url = admin_url( 'admin.php?page=wc-currency-suffix' );
        $links[] = '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Settings', 'wc-currency-suffix' ) . '</a>';
        return $links;
    }
}

new WCCS_Currency_Suffix();
